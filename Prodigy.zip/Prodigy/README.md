# Northstar account portal

Express and React authentication backed by SQLite. New registrations always receive the `user` role; role checks are enforced by the API, not by the client.

## Run locally

Requirements: Node.js 20.17 or newer and npm.

1. Install dependencies with `npm install`.
2. Copy `.env.example` to `.env` and set `SESSION_SECRET` to a random value of at least 32 characters.
3. Start the API and React development server with `npm run dev`.
4. Open `http://localhost:5173`.

The API is on port 3000. SQLite stores accounts and sessions in `data/app.sqlite`.

## Create an administrator

Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` in the environment, then run `npm run create-admin`. The password must be 12 to 72 UTF-8 bytes. This command creates or promotes the specified account. Never accept a role from public registration input.

PowerShell example:

```powershell
$env:ADMIN_EMAIL = "admin@example.com"
$env:ADMIN_PASSWORD = Read-Host "Admin password"
npm run create-admin
```

## Security notes

- Passwords use bcrypt with a cost factor of 12. Signup enforces a minimum of 12 characters and the bcrypt 72-byte maximum.
- Login sessions use `express-session` with a persistent SQLite store, HTTP-only cookies, `SameSite=Lax`, an eight-hour expiry, and session ID rotation after authentication.
- Mutating API requests require a session-bound CSRF token. Login and registration are rate-limited.
- Production requires a strong `SESSION_SECRET`; secure cookies are enabled when `NODE_ENV=production`. Serve production traffic over HTTPS and set `CLIENT_ORIGIN` to the exact frontend origin.
- The admin user-list endpoint is protected by server-side role middleware. Public signup cannot grant elevated roles.

For a production deployment, add operational controls such as HTTPS termination, secret management, backups, monitoring, and an account recovery process.