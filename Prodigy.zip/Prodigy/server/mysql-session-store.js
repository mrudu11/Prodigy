import session from 'express-session';

export class MySQLSessionStore extends session.Store {
  constructor(db) {
    super();
    this.db = db;
  }

  get(sid, callback) {
    this.db.execute('SELECT sess, expire FROM sessions WHERE sid = ?', [sid])
      .then(([rows]) => {
        const row = rows[0];
        if (!row) return callback(null, null);
        if (Number(row.expire) <= Date.now()) {
          return this.destroy(sid, (error) => callback(error, null));
        }
        callback(null, JSON.parse(row.sess));
      })
      .catch((error) => callback(error));
  }

  set(sid, sess, callback) {
    const expires = sess.cookie?.expires
      ? new Date(sess.cookie.expires).getTime()
      : Date.now() + (sess.cookie?.maxAge || 8 * 60 * 60 * 1000);

    this.db.execute(
      `INSERT INTO sessions (sid, sess, expire)
       VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE sess = VALUES(sess), expire = VALUES(expire)`,
      [sid, JSON.stringify(sess), expires],
    )
      .then(() => callback?.())
      .catch((error) => callback?.(error));
  }

  destroy(sid, callback) {
    this.db.execute('DELETE FROM sessions WHERE sid = ?', [sid])
      .then(() => callback?.())
      .catch((error) => callback?.(error));
  }

  touch(sid, sess, callback) {
    const expires = sess.cookie?.expires
      ? new Date(sess.cookie.expires).getTime()
      : Date.now() + (sess.cookie?.maxAge || 8 * 60 * 60 * 1000);

    this.db.execute('UPDATE sessions SET expire = ? WHERE sid = ?', [expires, sid])
      .then(() => callback?.())
      .catch((error) => callback?.(error));
  }
}