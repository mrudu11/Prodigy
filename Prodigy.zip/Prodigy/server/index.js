import 'dotenv/config';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import session from 'express-session';
import bcrypt from 'bcryptjs';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import { db } from './db.js';
import { MySQLSessionStore } from './mysql-session-store.js';

const app = express();
const port = Number(process.env.PORT || 3000);
const clientOrigin = process.env.CLIENT_ORIGIN || 'http://localhost:5173';
const isProduction = process.env.NODE_ENV === 'production';
const sessionSecret = process.env.SESSION_SECRET;
const dummyPasswordHash = await bcrypt.hash('not-a-real-user-password', 12);

if (isProduction && (!sessionSecret || sessionSecret.length < 32)) {
  throw new Error('SESSION_SECRET must be configured with at least 32 characters in production.');
}

if (!isProduction && !sessionSecret) {
  console.warn('Using a development-only session secret. Configure SESSION_SECRET before deployment.');
}

if (isProduction) app.set('trust proxy', 1);
app.use(helmet());
app.use(express.json({ limit: '10kb' }));
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', clientOrigin);
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-CSRF-Token');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.use(session({
  name: 'prodigy.sid',
  secret: sessionSecret || 'development-only-secret-change-before-deploying',
  store: new MySQLSessionStore(db),
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProduction,
    sameSite: 'lax',
    maxAge: 8 * 60 * 60 * 1000,
  },
}));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: { error: 'Too many attempts. Please try again later.' },
});
const csrfTokenFor = (req) => {
  if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  return req.session.csrfToken;
};

app.get('/api/auth/csrf', (req, res) => {
  res.set('Cache-Control', 'no-store').json({ csrfToken: csrfTokenFor(req) });
});

app.use('/api', (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const expected = req.session.csrfToken;
  const supplied = req.get('X-CSRF-Token');
  if (!expected || !supplied || expected.length !== supplied.length ||
      !crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(supplied))) {
    return res.status(403).json({ error: 'Invalid security token. Refresh and try again.' });
  }
  next();
});

const requireAuth = (req, res, next) => {
  if (!req.session.user) return res.status(401).json({ error: 'Authentication required.' });
  next();
};
const requireRole = (role) => (req, res, next) => {
  if (!req.session.user) return res.status(401).json({ error: 'Authentication required.' });
  if (req.session.user.role !== role) return res.status(403).json({ error: 'Access denied.' });
  next();
};
const regenerateSession = (req) => new Promise((resolve, reject) => {
  req.session.regenerate((error) => error ? reject(error) : resolve());
});
const saveSession = (req) => new Promise((resolve, reject) => {
  req.session.save((error) => error ? reject(error) : resolve());
});
const normalizeEmail = (email) => email.trim().toLowerCase();
const validEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
const validName = (name) => name.trim().length >= 2 && name.trim().length <= 80;

app.post('/api/auth/register', authLimiter, async (req, res, next) => {
  try {
    const name = typeof req.body.name === 'string' ? req.body.name : '';
    const email = typeof req.body.email === 'string' ? normalizeEmail(req.body.email) : '';
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    const confirmPassword = typeof req.body.confirmPassword === 'string' ? req.body.confirmPassword : '';

    if (!validName(name)) return res.status(400).json({ error: 'Please enter your full name.' });
    if (!validEmail(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
    if (password !== confirmPassword) return res.status(400).json({ error: 'Passwords do not match.' });
    const passwordBytes = Buffer.byteLength(password, 'utf8');
    if (passwordBytes < 12 || passwordBytes > 72) {
      return res.status(400).json({ error: 'Password must be 12 to 72 bytes long.' });
    }

    const [existingRows] = await db.execute('SELECT id FROM users WHERE email = ?', [email]);
    if (existingRows.length) return res.status(409).json({ error: 'An account with that email already exists.' });
    const passwordHash = await bcrypt.hash(password, 12);
    const [result] = await db.execute(
      'INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)',
      [name.trim(), email, passwordHash, 'user'],
    );
    await regenerateSession(req);
    req.session.user = { id: result.insertId, name: name.trim(), email, role: 'user' };
    csrfTokenFor(req);
    await saveSession(req);
    res.status(201).json({ user: req.session.user, csrfToken: req.session.csrfToken });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'An account with that email already exists.' });
    next(error);
  }
});

app.post('/api/auth/login', authLimiter, async (req, res, next) => {
  try {
    const email = typeof req.body.email === 'string' ? normalizeEmail(req.body.email) : '';
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    const [rows] = await db.execute('SELECT id, name, email, password_hash, role FROM users WHERE email = ?', [email]);
    const user = rows[0];
    const matches = await bcrypt.compare(password, user?.password_hash || dummyPasswordHash);
    if (!user || !matches) return res.status(401).json({ error: 'Email or password is incorrect.' });

    await regenerateSession(req);
    req.session.user = { id: user.id, name: user.name || '', email: user.email, role: user.role };
    csrfTokenFor(req);
    await saveSession(req);
    res.json({ user: req.session.user, csrfToken: req.session.csrfToken });
  } catch (error) {
    next(error);
  }
});

app.post('/api/auth/logout', requireAuth, (req, res, next) => {
  req.session.destroy((error) => {
    if (error) return next(error);
    res.clearCookie('prodigy.sid', { httpOnly: true, secure: isProduction, sameSite: 'lax' });
    res.sendStatus(204);
  });
});

app.get('/api/auth/me', (req, res) => {
  res.json({ user: req.session.user || null });
});

app.get('/api/account', requireAuth, async (req, res, next) => {
  try {
    const [rows] = await db.execute('SELECT id, name, email, role, created_at FROM users WHERE id = ?', [req.session.user.id]);
    const user = rows[0];
    if (!user) return res.status(404).json({ error: 'User not found.' });

    res.json({
      message: 'This protected account data is only available to authenticated users.',
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        created_at: user.created_at,
      },
    });
  } catch (error) {
    next(error);
  }
});

app.post('/api/account/profile', requireAuth, async (req, res, next) => {
  try {
    const name = typeof req.body.name === 'string' ? req.body.name.trim() : '';
    if (!validName(name)) return res.status(400).json({ error: 'Please enter a valid name.' });

    const [result] = await db.execute('UPDATE users SET name = ? WHERE id = ?', [name, req.session.user.id]);
    if (!result.affectedRows) return res.status(404).json({ error: 'User not found.' });

    req.session.user.name = name;
    await saveSession(req);
    res.json({ user: req.session.user, message: 'Profile updated successfully.' });
  } catch (error) {
    next(error);
  }
});

app.post('/api/account/password', requireAuth, async (req, res, next) => {
  try {
    const currentPassword = typeof req.body.currentPassword === 'string' ? req.body.currentPassword : '';
    const newPassword = typeof req.body.newPassword === 'string' ? req.body.newPassword : '';
    const confirmPassword = typeof req.body.confirmPassword === 'string' ? req.body.confirmPassword : '';

    if (!currentPassword || !newPassword || !confirmPassword) {
      return res.status(400).json({ error: 'All password fields are required.' });
    }
    if (newPassword !== confirmPassword) {
      return res.status(400).json({ error: 'New passwords do not match.' });
    }
    const passwordBytes = Buffer.byteLength(newPassword, 'utf8');
    if (passwordBytes < 12 || passwordBytes > 72) {
      return res.status(400).json({ error: 'Password must be 12 to 72 bytes long.' });
    }

    const [rows] = await db.execute('SELECT password_hash FROM users WHERE id = ?', [req.session.user.id]);
    const user = rows[0];
    if (!user) return res.status(404).json({ error: 'User not found.' });

    const matches = await bcrypt.compare(currentPassword, user.password_hash);
    if (!matches) return res.status(401).json({ error: 'Current password is incorrect.' });

    const passwordHash = await bcrypt.hash(newPassword, 12);
    await db.execute('UPDATE users SET password_hash = ? WHERE id = ?', [passwordHash, req.session.user.id]);
    res.json({ message: 'Password changed successfully.' });
  } catch (error) {
    next(error);
  }
});

app.get('/api/admin', requireRole('admin'), async (req, res, next) => {
  try {
    const [rows] = await db.execute('SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC');
    res.json({ users: rows });
  } catch (error) {
    next(error);
  }
});

const clientBuild = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../dist');
app.use(express.static(clientBuild));
app.get('*path', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(clientBuild, 'index.html'), (error) => error && next(error));
});

app.use((error, req, res, next) => {
  console.error(error);
  if (res.headersSent) return next(error);
  res.status(500).json({ error: 'An unexpected error occurred.' });
});

app.listen(port, () => console.log(`API listening on http://localhost:${port}`));