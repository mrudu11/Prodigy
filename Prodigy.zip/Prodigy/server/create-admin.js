import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { db } from './db.js';

const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
const password = process.env.ADMIN_PASSWORD;
if (!email || !password || Buffer.byteLength(password, 'utf8') < 12 || Buffer.byteLength(password, 'utf8') > 72) {
  console.error('Set ADMIN_EMAIL and an ADMIN_PASSWORD that is 12 to 72 bytes long.');
  process.exitCode = 1;
} else {
  const passwordHash = await bcrypt.hash(password, 12);
  await db.execute(
    `INSERT INTO users (email, password_hash, role)
     VALUES (?, ?, 'admin')
     ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), role = 'admin'`,
    [email, passwordHash],
  );
  console.log(`Admin account ready for ${email}`);
}
await db.end();