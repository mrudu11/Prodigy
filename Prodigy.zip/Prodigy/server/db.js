import mysql from 'mysql2/promise';

const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'manager',
  database: process.env.DB_NAME || 'prodigytask1',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
};

export const db = mysql.createPool(dbConfig);

export async function initDatabase() {
  const connection = await db.getConnection();

  try {
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(80) NOT NULL,
        email VARCHAR(254) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB;
    `);

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS sessions (
        sid VARCHAR(255) PRIMARY KEY,
        sess LONGTEXT NOT NULL,
        expire BIGINT NOT NULL
      ) ENGINE=InnoDB;
    `);

    const [indexRows] = await connection.execute(
      'SHOW INDEX FROM sessions WHERE Key_name = ?',
      ['idx_sessions_expire'],
    );

    if (!indexRows.length) {
      await connection.execute('CREATE INDEX idx_sessions_expire ON sessions (expire)');
    }
  } finally {
    connection.release();
  }
}

await initDatabase();