import { useEffect, useState } from 'react';

async function request(url, options = {}) {
  const response = await fetch(url, { credentials: 'include', ...options });
  if (response.status === 204) return null;
  const body = await response.json();
  if (!response.ok) throw new Error(body.error || 'Request failed.');
  return body;
}

export default function App() {
  const [user, setUser] = useState(null);
  const [mode, setMode] = useState('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [csrfToken, setCsrfToken] = useState('');
  const [account, setAccount] = useState(null);
  const [adminUsers, setAdminUsers] = useState(null);
  const [dashboardView, setDashboardView] = useState('dashboard');
  const [profileName, setProfileName] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [profileError, setProfileError] = useState('');
  const [profileSuccess, setProfileSuccess] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    Promise.all([request('/api/auth/csrf'), request('/api/auth/me')])
      .then(([csrf, session]) => {
        setCsrfToken(csrf.csrfToken);
        setUser(session.user);
      })
      .catch(() => setError('The service could not be reached. Is the server running?'));
  }, []);

  function resetProfileForms() {
    setProfileError('');
    setProfileSuccess('');
    setCurrentPassword('');
    setNewPassword('');
    setConfirmNewPassword('');
  }

  async function submit(event) {
    event.preventDefault();
    setBusy(true);
    setError('');
    try {
      const payload = mode === 'register'
        ? { name, email, password, confirmPassword }
        : { email, password };
      const result = await request(`/api/auth/${mode === 'register' ? 'register' : 'login'}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
        body: JSON.stringify(payload),
      });
      setUser(result.user);
      setCsrfToken(result.csrfToken);
      setName('');
      setEmail('');
      setPassword('');
      setConfirmPassword('');
      setAccount(null);
      setAdminUsers(null);
      setDashboardView('dashboard');
    } catch (requestError) {
      setError(requestError.message);
    } finally {
      setBusy(false);
    }
  }

  async function loadAccount() {
    setError('');
    resetProfileForms();
    setDashboardView('dashboard');
    try {
      const result = await request('/api/account');
      setAccount(result);
      setProfileName(result.user.name || '');
    } catch (requestError) {
      setError(requestError.message);
    }
  }

  async function updateProfile(event) {
    event.preventDefault();
    setProfileError('');
    setProfileSuccess('');
    try {
      const result = await request('/api/account/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
        body: JSON.stringify({ name: profileName }),
      });
      setUser(result.user);
      setProfileSuccess(result.message);
      setAccount((current) => current ? { ...current, user: result.user } : current);
      setProfileName(result.user.name || '');
    } catch (requestError) {
      setProfileError(requestError.message);
    }
  }

  async function changePassword(event) {
    event.preventDefault();
    setProfileError('');
    setProfileSuccess('');
    try {
      const result = await request('/api/account/password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
        body: JSON.stringify({ currentPassword, newPassword, confirmPassword: confirmNewPassword }),
      });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      setProfileSuccess(result.message);
    } catch (requestError) {
      setProfileError(requestError.message);
    }
  }

  async function loadAdmins() {
    setError('');
    resetProfileForms();
    setDashboardView('admin');
    try {
      const result = await request('/api/admin');
      setAdminUsers(result.users);
    } catch (requestError) {
      setError(requestError.message);
    }
  }

  async function logout() {
    setError('');
    try {
      await request('/api/auth/logout', {
        method: 'POST',
        headers: { 'X-CSRF-Token': csrfToken },
      });
      const csrf = await request('/api/auth/csrf');
      setCsrfToken(csrf.csrfToken);
      setUser(null);
      setAccount(null);
      setAdminUsers(null);
      setDashboardView('dashboard');
    } catch (requestError) {
      setError(requestError.message);
    }
  }

  const renderUserDashboard = () => (
    <div className="result-panel dashboard-panel">
      <span className="eyebrow">USER DASHBOARD</span>
      <h3>Welcome back, {user?.name || 'there'}.</h3>
      <div className="stats-grid">
        <div className="stat-card">
          <span className="stat-label">Role</span>
          <strong>{user?.role}</strong>
        </div>
        <div className="stat-card">
          <span className="stat-label">Email</span>
          <strong>{user?.email}</strong>
        </div>
      </div>
      {account && (
        <div className="user-profile-card">
          <div><strong>Name:</strong> {account.user.name}</div>
          <div><strong>Email:</strong> {account.user.email}</div>
          <div><strong>Role:</strong> {account.user.role}</div>
        </div>
      )}
    </div>
  );

  const renderProfilePage = () => (
    <div className="result-panel profile-panel">
      <span className="eyebrow">PROFILE</span>
      <h3>Personal details</h3>
      <div className="user-profile-card large">
        <div><strong>Name:</strong> {account?.user?.name || user?.name || 'Not set'}</div>
        <div><strong>Email:</strong> {account?.user?.email || user?.email}</div>
        <div><strong>Role:</strong> {account?.user?.role || user?.role}</div>
      </div>
      <form className="mini-form" onSubmit={updateProfile}>
        <label htmlFor="profileName">Edit profile name</label>
        <input id="profileName" value={profileName} onChange={(event) => setProfileName(event.target.value)} placeholder="Your name" />
        <button type="submit" className="action-button small">Save profile</button>
      </form>
      <form className="mini-form" onSubmit={changePassword}>
        <label htmlFor="currentPassword">Current password</label>
        <input id="currentPassword" type="password" value={currentPassword} onChange={(event) => setCurrentPassword(event.target.value)} placeholder="Current password" />
        <label htmlFor="newPassword">New password</label>
        <input id="newPassword" type="password" value={newPassword} onChange={(event) => setNewPassword(event.target.value)} placeholder="New password" />
        <label htmlFor="confirmNewPassword">Confirm new password</label>
        <input id="confirmNewPassword" type="password" value={confirmNewPassword} onChange={(event) => setConfirmNewPassword(event.target.value)} placeholder="Confirm new password" />
        <button type="submit" className="action-button small">Change password</button>
      </form>
      {profileError && <p className="error" role="alert">{profileError}</p>}
      {profileSuccess && <p className="success" role="status">{profileSuccess}</p>}
    </div>
  );

  const renderAdminPanel = () => (
    <div className="result-panel admin-panel">
      <span className="eyebrow">ADMIN DASHBOARD</span>
      <h3>Manage users</h3>
      <div className="stats-grid admin-grid">
        <div className="stat-card">
          <span className="stat-label">Total users</span>
          <strong>{adminUsers?.length || 0}</strong>
        </div>
        <div className="stat-card">
          <span className="stat-label">Access</span>
          <strong>Admin</strong>
        </div>
      </div>
      <div className="admin-list">
        {adminUsers && adminUsers.map((item) => (
          <div className="user-row" key={item.id}>
            <span>{item.name || item.email}</span>
            <span>{item.email}</span>
            <span>{item.role}</span>
          </div>
        ))}
        {!adminUsers && <button className="action-button" type="button" onClick={loadAdmins}>Load users</button>}
      </div>
    </div>
  );

  return (
    <main className="shell">
      <section className="intro" aria-label="Northstar account portal">
        <a className="wordmark" href="/" aria-label="Northstar home"><span className="mark">N</span> NORTHSTAR</a>
        <div className="intro-copy">
          <p className="eyebrow">ACCOUNT PORTAL / 01</p>
          <h1>Your work,<br />in good hands.</h1>
          <p className="intro-note">A considered space for your team, your projects, and the work ahead.</p>
        </div>
        <div className="intro-footer"><span>PRIVATE BY DESIGN</span><span>EST. 2024</span></div>
      </section>

      <section className="workspace">
        {!user ? (
          <div className="auth-panel">
            <p className="eyebrow">WELCOME TO NORTHSTAR</p>
            <h2>{mode === 'login' ? 'Sign in' : 'Create your account'}</h2>
            <p className="subheading">{mode === 'login' ? 'Pick up right where you left off.' : 'Start with a secure personal account.'}</p>
            <div className="mode-switch" role="tablist" aria-label="Account action">
              <button role="tab" aria-selected={mode === 'login'} className={mode === 'login' ? 'active' : ''} onClick={() => { setMode('login'); setError(''); }}>Sign in</button>
              <button role="tab" aria-selected={mode === 'register'} className={mode === 'register' ? 'active' : ''} onClick={() => { setMode('register'); setError(''); }}>Register</button>
            </div>
            <form onSubmit={submit} className="auth-form">
              {mode === 'register' && (
                <>
                  <label htmlFor="name">Full name</label>
                  <input id="name" type="text" autoComplete="name" required minLength={2} maxLength="80" value={name} onChange={(event) => setName(event.target.value)} placeholder="Your full name" />
                </>
              )}
              <label htmlFor="email">Email address</label>
              <input id="email" type="email" autoComplete="email" required maxLength="254" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@company.com" />
              <div className="label-row"><label htmlFor="password">Password</label>{mode === 'register' && <span>12+ characters</span>}</div>
              <input id="password" type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required minLength={mode === 'register' ? 12 : 1} maxLength="72" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Enter your password" />
              {mode === 'register' && (
                <>
                  <label htmlFor="confirmPassword">Confirm password</label>
                  <input id="confirmPassword" type="password" autoComplete="new-password" required minLength={12} maxLength="72" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} placeholder="Re-enter your password" />
                </>
              )}
              {error && <p className="error" role="alert">{error}</p>}
              <button className="primary-button" type="submit" disabled={busy || !csrfToken}>{busy ? 'Please wait…' : mode === 'login' ? 'Sign in securely' : 'Create account'}<span aria-hidden="true">↗</span></button>
            </form>
            {mode === 'login' && (
              <button type="button" className="text-button" onClick={() => setError('Use the admin account or contact support to reset your password.')}>Forgot password?</button>
            )}
            <p className="fine-print">Protected with encrypted sessions and modern password hashing.</p>
          </div>
        ) : (
          <div className="auth-panel signed-in">
            <p className="eyebrow">YOUR NORTHSTAR</p>
            <h2>Good to have<br />you back.</h2>
            <p className="subheading">Signed in as <strong>{user.email}</strong></p>
            <span className={`role-tag ${user.role === 'admin' ? 'admin' : ''}`}>{user.role}</span>

            <div className="dashboard-tabs" role="tablist" aria-label="User dashboard navigation">
              <button type="button" className={dashboardView === 'dashboard' ? 'active' : ''} onClick={() => { setDashboardView('dashboard'); resetProfileForms(); }}>Dashboard</button>
              <button type="button" className={dashboardView === 'profile' ? 'active' : ''} onClick={() => { setDashboardView('profile'); if (account) setProfileName(account.user.name || ''); resetProfileForms(); }}>Profile</button>
              {user.role === 'admin' && (
                <button type="button" className={dashboardView === 'admin' ? 'active' : ''} onClick={() => { setDashboardView('admin'); setError(''); loadAdmins(); }}>Admin</button>
              )}
            </div>

            {dashboardView === 'dashboard' && !user.role && renderUserDashboard()}
            {dashboardView === 'dashboard' && user.role === 'user' && renderUserDashboard()}
            {dashboardView === 'profile' && renderProfilePage()}
            {dashboardView === 'admin' && renderAdminPanel()}

            {error && <p className="error" role="alert">{error}</p>}
            <button className="signout-button" onClick={logout}>Sign out <span aria-hidden="true">↗</span></button>
          </div>
        )}
        <div className="workspace-footer"><span>SECURE ACCESS</span><span>© NORTHSTAR 2024</span></div>
      </section>
    </main>
  );
}